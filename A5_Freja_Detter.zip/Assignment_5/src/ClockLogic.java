
public class ClockLogic {

	public ClockLogic() {
		// TODO Auto-generated constructor stub
	}

}
