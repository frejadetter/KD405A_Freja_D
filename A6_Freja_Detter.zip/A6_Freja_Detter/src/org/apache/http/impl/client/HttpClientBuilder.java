package org.apache.http.impl.client;

public class HttpClientBuilder {

}
