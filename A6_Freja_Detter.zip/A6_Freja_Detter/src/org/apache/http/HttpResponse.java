package org.apache.http;

public class HttpResponse {

}
