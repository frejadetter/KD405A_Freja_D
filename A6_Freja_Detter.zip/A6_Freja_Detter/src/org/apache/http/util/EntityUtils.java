package org.apache.http.util;

public class EntityUtils {

}
