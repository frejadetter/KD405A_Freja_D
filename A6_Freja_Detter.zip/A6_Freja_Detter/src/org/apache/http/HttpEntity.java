package org.apache.http;

public class HttpEntity {

}
