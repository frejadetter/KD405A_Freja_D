package org.apache.http.client;

import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpPost;

public class HttpClient {

	public HttpResponse execute(HttpPost httpPost) {
		// TODO Auto-generated method stub
		return null;
	}

}
