package org.apache.http.client.methods;

public class HttpPost {

}
